# Architecture and design notes

## Data flow

1. `simulator/client.py` opens a TCP connection to `127.0.0.1:4444`.
2. It sends a small set of predefined JSON events.
3. `simulator/server.py` validates that each line is a JSON object, adds a UTC receive timestamp, appends it to `logs/events.jsonl`, and replies `ACK`.
4. `detection/detector.py` reads the JSONL log and reports configured indicators.

## Safety controls

- Both client and server use loopback only (`127.0.0.1`).
- No command execution API exists.
- Command-like content is explicitly marked `executed: false`.
- No persistence, stealth, credential access, or file collection is implemented.
- No external network destination is configurable.

## Analyst interpretation

A reverse connection is a networking pattern, not a malware verdict by itself. Assess process lineage, destination reputation, user activity, DNS, timing, and endpoint context together.
