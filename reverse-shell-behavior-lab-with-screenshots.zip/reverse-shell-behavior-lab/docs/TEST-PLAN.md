# Test plan

| ID | Procedure | Expected result |
|---|---|---|
| T01 | Start `python3 simulator/server.py` | Server binds to 127.0.0.1:4444 |
| T02 | Run `python3 simulator/client.py` | Client receives ACK for each JSON event |
| T03 | Inspect `logs/events.jsonl` | Valid JSON object per line, with receive timestamp |
| T04 | Run `python3 detection/detector.py` | Reports test-port and simulated-command indicators |
| T05 | Stop server, rerun client | Friendly connection-refused message |
| T06 | Run `sudo tcpdump -i lo -nn 'tcp port 4444'` during test | Local TCP packets appear |
| T07 | Review Windows Sysmon events | Windows event telemetry appears if configured; WSL Linux process telemetry may not appear as native Windows process events |

## Evidence

Save screenshots in `screenshots/` and describe the test, timestamp, expected result, actual result, and any deviation.
