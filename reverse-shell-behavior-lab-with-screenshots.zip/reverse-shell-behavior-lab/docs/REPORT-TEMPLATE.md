# Malware Behaviour Simulation and Detection — Report

## 1. Executive summary
Describe the objective and outcome in 3–5 sentences.

## 2. Scope and authorization
State that testing was performed on the local Windows + WSL lab only.

## 3. Environment
- Windows version:
- WSL distribution/version:
- Python version:
- Sysmon version/configuration:
- Wireshark/tcpdump version:

## 4. Methodology
Explain the local TCP simulation, JSONL event collection, and detection logic.

## 5. Test results
| Test ID | Expected result | Actual result | Pass/Fail | Evidence |
|---|---|---|---|---|

## 6. Findings
Separate observed facts from analyst interpretation. Include timestamps and relevant event fields.

## 7. Detection limitations
Discuss false positives, telemetry gaps, and why a port/process indicator alone is insufficient.

## 8. Recommendations
List practical monitoring and response improvements.

## 9. Conclusion
Summarize what was learned and possible next steps.
