"""Local-only JSON event collector for the reverse-shell behaviour lab."""
import json
import socket
from datetime import datetime, timezone
from pathlib import Path

HOST = "127.0.0.1"
PORT = 4444
LOG_PATH = Path(__file__).resolve().parents[1] / "logs" / "events.jsonl"


def write_event(event: dict) -> None:
    event["received_at"] = datetime.now(timezone.utc).isoformat()
    LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
    with LOG_PATH.open("a", encoding="utf-8") as log_file:
        log_file.write(json.dumps(event, sort_keys=True) + "\n")
    print(f"[EVENT] {event}")


def main() -> None:
    # Bind exclusively to loopback: this collector is not exposed to the LAN.
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server:
        server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        server.bind((HOST, PORT))
        server.listen(5)
        print(f"[+] Lab collector listening on {HOST}:{PORT}")
        print(f"[+] Writing events to {LOG_PATH}")

        try:
            while True:
                connection, address = server.accept()
                with connection:
                    print(f"[+] Local client connected: {address}")
                    stream = connection.makefile("r", encoding="utf-8")
                    for line in stream:
                        try:
                            event = json.loads(line)
                            if not isinstance(event, dict):
                                raise ValueError("event must be a JSON object")
                            write_event(event)
                            connection.sendall(b"ACK\n")
                        except (json.JSONDecodeError, ValueError) as exc:
                            connection.sendall(f"ERROR: {exc}\n".encode())
        except KeyboardInterrupt:
            print("\n[+] Collector stopped.")


if __name__ == "__main__":
    main()
