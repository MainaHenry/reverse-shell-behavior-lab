"""Send harmless, predefined telemetry to the local lab collector."""
import json
import socket
import time
from datetime import datetime, timezone

HOST = "127.0.0.1"
PORT = 4444

EVENTS = [
    {"event_type": "process_start", "process": "python3",
     "description": "Lab simulator process"},
    {"event_type": "network_connect", "destination": "127.0.0.1:4444",
     "description": "Local test connection"},
    {"event_type": "simulated_command", "command_label": "whoami",
     "executed": False, "description": "Command represented as data only"},
    {"event_type": "heartbeat", "description": "First simulated callback"},
    {"event_type": "heartbeat", "description": "Second simulated callback"},
]


def main() -> None:
    # Destination is deliberately fixed to loopback; no CLI override is offered.
    try:
        with socket.create_connection((HOST, PORT), timeout=5) as client:
            print(f"[+] Connected to local collector at {HOST}:{PORT}")
            reader = client.makefile("r", encoding="utf-8")
            for event in EVENTS:
                event["event_time"] = datetime.now(timezone.utc).isoformat()
                client.sendall((json.dumps(event) + "\n").encode("utf-8"))
                reply = reader.readline().strip()
                print(f"[collector] {reply}")
                time.sleep(1)
    except ConnectionRefusedError:
        print("[!] Collector is not running. Start simulator/server.py first.")
    except OSError as exc:
        print(f"[!] Network error: {exc}")


if __name__ == "__main__":
    main()
