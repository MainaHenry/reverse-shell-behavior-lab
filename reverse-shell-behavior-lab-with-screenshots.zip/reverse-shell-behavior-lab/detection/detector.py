"""Simple defensive analysis of JSONL events produced by this lab."""
import json
from collections import Counter
from datetime import datetime
from pathlib import Path

LOG_PATH = Path(__file__).resolve().parents[1] / "logs" / "events.jsonl"


def parse_time(value):
    if not value:
        return None
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None


def main() -> None:
    if not LOG_PATH.exists():
        raise SystemExit("[!] No event log found. Run the simulator first.")

    events = []
    with LOG_PATH.open(encoding="utf-8") as source:
        for line_number, line in enumerate(source, start=1):
            try:
                item = json.loads(line)
                if isinstance(item, dict):
                    events.append(item)
            except json.JSONDecodeError:
                print(f"[!] Skipping malformed JSON on line {line_number}")

    counts = Counter(e.get("event_type", "unknown") for e in events)
    alerts = []

    for event in events:
        kind = event.get("event_type")
        if kind == "simulated_command" and event.get("executed") is False:
            alerts.append("SIMULATION: command-like activity represented as data (not executed)")
        if kind == "network_connect" and event.get("destination") == "127.0.0.1:4444":
            alerts.append("LAB INDICATOR: connection to the local test collector")
        if kind == "process_start" and event.get("process") in {"python3", "powershell.exe", "cmd.exe"}:
            alerts.append(f"REVIEW: inspect process context for {event.get('process')}")

    heartbeat_times = [
        parse_time(e.get("event_time"))
        for e in events if e.get("event_type") == "heartbeat"
    ]
    heartbeat_times = sorted(t for t in heartbeat_times if t is not None)
    if len(heartbeat_times) >= 2:
        intervals = [
            (b - a).total_seconds()
            for a, b in zip(heartbeat_times, heartbeat_times[1:])
        ]
        avg = sum(intervals) / len(intervals)
        alerts.append(f"BEHAVIOUR: {len(heartbeat_times)} heartbeat events; average interval {avg:.2f}s")

    print("\n=== REVERSE-SHELL BEHAVIOUR LAB: DETECTION REPORT ===")
    print(f"Events analysed: {len(events)}")
    print("\nEvent counts:")
    for name, count in sorted(counts.items()):
        print(f"  {name}: {count}")

    print("\nFindings:")
    if alerts:
        for alert in alerts:
            print(f"  [!] {alert}")
    else:
        print("  [+] No configured indicators found.")

    print("\nAnalyst note: indicators are leads for investigation, not proof of compromise.")


if __name__ == "__main__":
    main()
