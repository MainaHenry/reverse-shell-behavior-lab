# Reverse Shell Behaviour Lab

A defensive cybersecurity portfolio project for **Windows + WSL**. It simulates selected behaviours associated with reverse-shell activity using harmless TCP messages, records telemetry as JSONL, and detects suspicious patterns.

> **Safety:** This project is a simulator, not malware. It does not provide an interactive shell, execute received commands, persist, evade detection, steal data, or contact external hosts. The client is hard-coded to `127.0.0.1`.

## Project goals

- Understand outbound TCP connection and callback concepts.
- Generate structured security telemetry.
- Detect simulated command messages, repeated callbacks, and unexpected test-port use.
- Practise packet inspection and Windows event-log review.
- Produce reproducible evidence for a security portfolio.

## Architecture

```text
WSL loopback (127.0.0.1)
┌────────────────────┐       TCP/JSON       ┌────────────────────┐
│ simulator/client.py├────────────────────►│ simulator/server.py│
│ harmless test data │◄─────────────────────┤ JSONL event logger │
└────────────────────┘        ACK           └─────────┬──────────┘
                                                      │
                                               logs/events.jsonl
                                                      │
                                           ┌──────────▼─────────┐
                                           │ detection/detector │
                                           │ alerts + summary   │
                                           └────────────────────┘
```

## Requirements

- Windows 10/11
- WSL 2 with Ubuntu (or another Linux distribution)
- Python 3.10+
- Optional: Sysmon for Windows telemetry, Wireshark, `tcpdump`

No third-party Python packages are required.

## Quick start (WSL)

```bash
# In Ubuntu / WSL
sudo apt update
sudo apt install -y python3 python3-venv tcpdump

git clone https://github.com/<YOUR-USERNAME>/reverse-shell-behavior-lab.git
cd reverse-shell-behavior-lab

python3 -m venv .venv
source .venv/bin/activate
```

### Terminal 1 — start the local collector

```bash
python3 simulator/server.py
```

### Terminal 2 — send harmless simulated events

```bash
python3 simulator/client.py
```

The client connects only to `127.0.0.1:4444`. It sends JSON records such as `process_start`, `network_connect`, `simulated_command` (with `executed: false`), and `heartbeat`. The server replies with `ACK` and writes records to `logs/events.jsonl`.

### Run detections

```bash
python3 detection/detector.py
```

The detector reports event counts, suspicious simulated activity, and callback timing observations.

## Network inspection

In a third WSL terminal:

```bash
sudo tcpdump -i lo -nn 'tcp port 4444'
```

Run the client again while capture is active. Stop capture with `Ctrl+C`.

Wireshark display filter:

```text
tcp.port == 4444
```

Because this demo runs inside WSL and uses WSL loopback, capture on the WSL loopback interface. Windows Sysmon does not necessarily see Linux processes running inside WSL as ordinary Windows processes.

## Windows Sysmon (optional)

Install Sysmon from the official Microsoft Sysinternals page:
https://learn.microsoft.com/sysinternals/downloads/sysmon

From an elevated PowerShell window in the extracted Sysmon directory:

```powershell
.\Sysmon64.exe -accepteula -i
```

Check the service and review recent events:

```powershell
Get-Service Sysmon64
Get-WinEvent -LogName 'Microsoft-Windows-Sysmon/Operational' -MaxEvents 20 |
  Select-Object TimeCreated, Id, Message
```

Network connection event ID 3 is not enabled by default in every Sysmon configuration. Use a reviewed Sysmon configuration that enables it before expecting network events. Sysmon logs Windows activity; it is not a replacement for WSL packet capture.

## Detection logic

The Python detector looks for:
- A `simulated_command` event (the command is data only and is never run).
- A connection event that references the lab port.
- Repeated heartbeat events and their time intervals.
- Selected process names for analyst review, not automatic malware verdicts.

The Sigma example in `rules/` is a starting point. Field names must be mapped to the schema emitted by your Sysmon version and SIEM backend before production use.

## Test plan

| ID | Test | Expected result |
|---|---|---|
| T01 | Start collector | Binds to `127.0.0.1:4444` |
| T02 | Run client | Receives ACK responses |
| T03 | Inspect `logs/events.jsonl` | One JSON object per event |
| T04 | Run detector | Reports simulated command and port alerts |
| T05 | Stop collector and run client | Client reports connection failure |
| T06 | Capture with tcpdump | Loopback TCP traffic on port 4444 |
| T07 | Review Sysmon | Windows telemetry is available if configured |

## Repository layout

```text
.
├── README.md
├── LICENSE
├── .gitignore
├── simulator/
│   ├── server.py
│   └── client.py
├── detection/
│   └── detector.py
├── rules/
│   └── suspicious-lab-port.yml
├── docs/
│   ├── ARCHITECTURE.md
│   ├── TEST-PLAN.md
│   └── REPORT-TEMPLATE.md
├── logs/
│   └── .gitkeep
└── screenshots/
    └── .gitkeep
```

## Portfolio evidence to add

Add your own screenshots to `screenshots/`:
1. Collector running.
2. Client receiving ACKs.
3. Detection report.
4. `tcpdump` or Wireshark capture.
5. Sysmon event viewer (if configured).

Do not include real credentials, private IP information you do not want public, or personal data in screenshots.

## Limitations

This is a controlled behaviour simulator. A port match or process name alone is not proof of compromise. Correlate process, network, DNS, and endpoint context before making an incident finding.

## Learning references

- Microsoft Sysmon: https://learn.microsoft.com/sysinternals/downloads/sysmon
- Wireshark: https://www.wireshark.org/docs/
- MITRE ATT&CK: https://attack.mitre.org/
- Sigma: https://sigmahq.io/
